import javax.xml.bind.annotation.XmlElement;

public class Card {
    private int id;
    private String description;
    private String title;
    private String optionA;
    private String optionB;

    public int getId() {
        return id;
    }

    public String getDescription() {
        return description;
    }

    public String getTitle() {
        return title;
    }

    public String getOptionA() {
        return optionA;
    }

    public String getOptionB() {
        return optionB;
    }
    @XmlElement
    public void setId(int id) {
        this.id = id;
    }
    @XmlElement
    public void setDescription(String description) {
        this.description = description;
    }
    @XmlElement
    public void setTitle(String title) {
        this.title = title;
    }
    @XmlElement
    public void setOptionA(String optionA) {
        this.optionA = optionA;
    }
    @XmlElement
    public void setOptionB(String optionB) {
        this.optionB = optionB;
    }
}
