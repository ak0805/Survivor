import window.NewWindow;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Unmarshaller;
import java.io.File;


public class Main {


    public static void main(String[] args) throws JAXBException {
        new NewWindow().setVisible(true);



        File file = new File("example.xml");
        JAXBContext jaxbContext = JAXBContext.newInstance(Cards.class);
        Unmarshaller unmarshaller = jaxbContext.createUnmarshaller();

        Cards cards = (Cards) unmarshaller.unmarshal(file);
        System.out.println(cards);

}}
