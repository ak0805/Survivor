package window;

import javax.swing.*;
import javax.swing.text.html.Option;
import java.awt.event.*;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.PrintWriter;
import java.nio.file.Files;
import java.nio.file.OpenOption;
import java.nio.file.StandardOpenOption;

public class NewWindow extends JFrame implements ActionListener {
    Canvas canvas = new Canvas();
    GameWindow gameWindow = new GameWindow();

    public NewWindow() {
        super("Survivor Game");
        canvas.setLayout(null);
        JTextArea textField = new JTextArea();
        textField.setBounds(235, 220, 200, 20);
        JButton startButton = new JButton("START GAME");
        startButton.setBounds(235, 250, 200, 50);
        startButton.addActionListener(e -> {
            setVisible(false);
            gameWindow.setVisible(true);
            String nick = textField.getText();
            try {
                Files.write(new File("nicks.txt").toPath(),nick.getBytes(), StandardOpenOption.CREATE, StandardOpenOption.TRUNCATE_EXISTING);
            } catch (IOException e1) {
                e1.printStackTrace();
            }
        });


        setSize(654, 436);
        setResizable(false);

        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        canvas.add(textField);
        canvas.add(startButton);
        add(canvas);
    }

    @Override
    public void actionPerformed(ActionEvent e) {

    }
}
