import javax.xml.bind.annotation.XmlElement;

public class Card {
    private int cardId;
    private String desc;
    private String title;
    private String optionA;
    private String optionB;
    private String cardDesc;

    Effects effects = new Effects();

    public int getCardId() {return cardId;}

    public String getCardDesc(){return cardDesc;}

    public String getDescription() {
        return desc;
    }

    public String getTitle() {
        return title;
    }

    public String getOptionA() {
        return optionA;
    }

    public String getOptionB() {
        return optionB;
    }

    @XmlElement
    public void setCardId(int cardId) {
        this.cardId = cardId;
    }
    @XmlElement
    public void setCardDesc(String cardDesc) {
        this.cardDesc = cardDesc;
    }
    @XmlElement
    public void setDescription(String desc) {
        this.desc = desc;
    }
    @XmlElement
    public void setTitle(String title) {
        this.title = title;
    }
    @XmlElement
    public void setOptionA(String optionA) {
        this.optionA = optionA;
    }
    @XmlElement
    public void setOptionB(String optionB) {
        this.optionB = optionB;
    }
}
