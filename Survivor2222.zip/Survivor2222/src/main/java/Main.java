import window.NewWindow;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Unmarshaller;
import java.io.File;
import java.util.List;


public class Main {


    public static void main(String[] args) throws JAXBException {
        new NewWindow().setVisible(true);



        File file = new File("cards.xml");
        JAXBContext jaxbContext = JAXBContext.newInstance(Cards.class);
        Unmarshaller unmarshaller = jaxbContext.createUnmarshaller();

        Cards cards = (Cards) unmarshaller.unmarshal(file);
        List<Card> cards1 = cards.getCards();


        cards1.forEach(System.out::println);

}}
