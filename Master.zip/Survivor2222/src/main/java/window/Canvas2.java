package window;

import images.ReadImages;

import javax.smartcardio.Card;
import javax.swing.*;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.awt.Color;
import java.util.List;
import java.util.Map;

public class Canvas2 extends JPanel {

    public static final Color HUNGER = new Color(122, 65, 2);
    public static final Color HEALTH = new Color(255, 0, 0);
    public static final Color WATER = new Color(0, 128, 255);
    public static final Color BRAIN = new Color(255, 102, 179);

    public Canvas2() {
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);

        ReadImages readImages = new ReadImages();
        Map<String, BufferedImage> stringBufferedImageMap = readImages.readingNamesOfImagesFromFiles();

        g.drawImage(stringBufferedImageMap.get("game.jpg"), 0, 0, null);
        g.drawImage(stringBufferedImageMap.get("heart.png"), 945, 35, 40, 40, null);
        g.drawImage(stringBufferedImageMap.get("drop.png"), 940, 90, 50, 50, null);
        g.drawImage(stringBufferedImageMap.get("fish.png"), 945, 150, 44, 44, null);
        g.drawImage(stringBufferedImageMap.get("brain.png"), 930, 195, 70, 70, null);
        g.setFont(new Font("Old English Text MT", Font.BOLD, 25));
        g.setColor(Color.BLACK);
        g.drawString(readImages.showNick, 1000, 30);

        g.drawRect(1000, 46, 150, 22);
        g.drawRect(1000, 101, 150, 22);
        g.drawRect(1000, 161, 150, 22);
        g.drawRect(1000, 216, 150, 22);

        g.setColor(HEALTH);
        g.fillRect(1001, 47, 149, 21);
        g.setColor(WATER);
        g.fillRect(1001, 102, 149, 21);
        g.setColor(HUNGER);
        g.fillRect(1001, 162, 149, 21);
        g.setColor(BRAIN);
        g.fillRect(1001, 217, 149, 21);

    }

}

