import window.NewWindow;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Unmarshaller;
import java.io.File;
import java.util.List;
import java.util.Random;


public class Main {


    public static void main(String[] args) throws JAXBException {
        new NewWindow().setVisible(true);
        Random generate = new Random();
        int a = generate.nextInt(1); //when we will have more cards. we will set larger bounds, but right now we have only one

        XmlReader<Cards> cardsXmlReader = new XmlReader<>();
        Cards cards = cardsXmlReader.readXml(new File("cards.xml"), Cards.class);
        List<Card> cardsList = cards.getCards();
        Card card = cardsList.get(a);
        System.out.println(card.getTitle());

        //If you would know, what is happening here and why this in this class
        //So here we would show things on our game window
        //But I don't know, how to do it in canvas, tbh XD

        XmlReader<Effects> effectsXmlReader  = new XmlReader<>();
        Effects effects = effectsXmlReader.readXml(new File("effects.xml"), Effects.class);
        List<Effect> effectsList = effects.getEffects();
        Effect effect = effectsList.get(0);

        XmlReader<Options> optionsXmlReader = new XmlReader<>();
        Options options = optionsXmlReader.readXml(new File("options.xml"), Options.class);
        List<Option> optionsList = options.getOptions();
        Option option = optionsList.get(0);
}}
