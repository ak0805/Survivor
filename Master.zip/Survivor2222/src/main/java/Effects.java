import javax.xml.bind.annotation.*;
import java.util.List;

@XmlRootElement(name = "effects")
public class Effects {

    private List<Effect> effects;

    public Effects() {
    }

    @XmlElements(@XmlElement(name = "effect"))
    public List<Effect> getEffects() {
        return effects;
    }

    public void setEffects(List<Effect> effects) {
        this.effects = effects;
    }
}
