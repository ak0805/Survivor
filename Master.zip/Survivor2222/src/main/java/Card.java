import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name = "card")
@XmlAccessorType(XmlAccessType.FIELD)
public class Card {

    private int cardId;
    private String title;
    private String cardDesc;
    private int optionAId;
    private int optionBId;

    public Card() {
    }

    public int getCardId() {
        return cardId;
    }

    public void setCardId(int cardId) {
        this.cardId = cardId;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getCardDesc() {
        return cardDesc;
    }

    public void setCardDesc(String cardDesc) {
        this.cardDesc = cardDesc;
    }

    public int getOptionAId() {
        return optionAId;
    }

    public void setOptionAId(int optionAId) {
        this.optionAId = optionAId;
    }

    public int getOptionBId() {
        return optionBId;
    }

    public void setOptionBId(int optionBId) {
        this.optionBId = optionBId;
    }
}
