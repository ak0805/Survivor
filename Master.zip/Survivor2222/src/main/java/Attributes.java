import java.util.HashMap;
import java.util.Map;

public class Attributes {

    public Attributes() {
    }

    private String health;
    private int healthValue = 69;
    private String water;
    private int waterValue = 100;
    private String food;
    private int foodValue = 100;
    private String stamina;
    private int staminaValue = 100;

    public void attributes() {
    Map<String, Integer> att = new HashMap<>();
    att.put(health, healthValue);
    att.put(water, waterValue);
    att.put(food, foodValue);
    att.put(stamina, staminaValue);
}
}
