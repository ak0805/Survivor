package Window;

import javax.imageio.ImageIO;
import javax.swing.*;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.util.Objects;
import java.awt.Color;
public class Canvas2 extends JPanel {

    BufferedImage img;
    BufferedImage water;
    BufferedImage heart;
    BufferedImage fish;
    BufferedImage brain;
    public static final Color VERY_LIGHT_RED = new Color(12,75,31);
    public Canvas2() {
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        {
            try {
                img = ImageIO.read(new File("Game.jpg"));
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        {
            try {
                brain = ImageIO.read(new File("błain.png"));
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        {
            try {
                water = ImageIO.read(new File("kłopla.png"));
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        {
            try {
                heart = ImageIO.read(new File("serce.png"));
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        {
            try {
                fish = ImageIO.read(new File("łyba.png"));
            } catch (IOException e) {
                e.printStackTrace();
            }
        }

        g.drawImage(img,0,0,null);
        g.drawImage(fish,945, 150, 44, 44,null);
        g.drawRect(1000, 161, 150, 22);
        g.fillRect(1001, 162, 148, 20);
        g.drawImage(heart,940,30, 50, 50,null);

        g.drawImage(water,940,90, 50, 50,null);
        g.drawImage(brain,930,205, 70, 70,null);
        g.setColor(VERY_LIGHT_RED);
        //g.fillRoundRect(970, 35, 300, 300, 15, 15);


    }




}

