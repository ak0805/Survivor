package Window;

import javax.swing.*;
import java.awt.*;

public class GameWindow extends JFrame {
    Canvas2 canvas2=new Canvas2();

    public GameWindow()  {
        setSize(1210,757);

        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        add(canvas2);
    }
}
