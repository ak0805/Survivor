package Main;

import Window.GameWindow;
import Window.NewWindow;

import java.util.ArrayList;
import java.util.List;

public class Main {
    public static void main(String[] args) {
        new NewWindow().setVisible(true);

    }
}
