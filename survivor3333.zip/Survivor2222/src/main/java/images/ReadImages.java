package images;

import javax.imageio.ImageIO;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.HashMap;
import java.util.Map;
import java.util.stream.Stream;

public class ReadImages {


    ClassLoader classLoader = getClass().getClassLoader();
    String filePath = classLoader.getResource("images.txt").getFile();

    public String showNick;
    {
        try {
            showNick = String.valueOf(Files.readAllLines(Paths.get("nicks.txt")));
            showNick = showNick.replaceAll("\\[", "").replaceAll("\\]","");
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public Map<String,BufferedImage> readingNamesOfImagesFromFiles() {
        Map<String,BufferedImage> namesOfFiles=new HashMap<>();
        File file1 = new File(filePath);
        try (Stream<String> stream = Files.lines(file1.toPath())) {
           stream.forEach(e->{
               BufferedImage img = null;
               String filePath = classLoader.getResource(e).getFile();
               File file = new File(filePath);
               try {
                   img = ImageIO.read(file);
               } catch (IOException e1) {
                   e1.printStackTrace();
               }

               namesOfFiles.put(e, img);
                   }
           );
        } catch (IOException e) {
            e.printStackTrace();
        }
        return namesOfFiles;
    }


}
