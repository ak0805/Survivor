package Window;

import javax.swing.*;

public class NewWindow extends JFrame {
    Canvas canvas =new Canvas();

    public NewWindow() {
        super("Survivor Game");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(670,436);



        add(canvas);


    }


}