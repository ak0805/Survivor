package Window;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;

public class NewWindow extends JFrame {
    Canvas canvas = new Canvas();

    public NewWindow() {
        super("Survivor Game");
        JButton startButton = new JButton("START GAME");
        startButton.setLocation(50, 371);
        startButton.setPreferredSize(new Dimension(150, 50));
        JButton optionButton = new JButton("OPTION");


        setSize(670, 436);
        //canvas.setLayout(new BoxLayout(canvas, BoxLayout.PAGE_AXIS));
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        canvas.add(startButton);
        canvas.add(optionButton);
        add(canvas);

    }

}