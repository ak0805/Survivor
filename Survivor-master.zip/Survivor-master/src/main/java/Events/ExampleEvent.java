package Events;

public class ExampleEvent {
    String title;
    String opis;
    String whatever;
}
