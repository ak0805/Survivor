package Main;

import Window.NewWindow;

public class Main {
    public static void main(String[] args) {
        new NewWindow().setVisible(true);
    }
}
